from pathlib import Path
import csv
import importlib.metadata
import json

HERE=Path(__file__).resolve().parent
EXPERIMENT=HERE.parent
r=json.loads((HERE/'cycle-analysis.json').read_text())
raw=json.loads((EXPERIMENT/'results.json').read_text())
best=r['bestUnverifiedRawCycle'];partial=r['bestPartialCycle']
complete=[c for c in r['candidates'] if c['completeRawOscillation']]
lines=['PetLens: walking-cycle feasibility demonstration','',
'Outcome: no complete RELIABLE anatomical walking cycle has been established. Three complete raw one-paw oscillation intervals were found; two overlap and must not be counted as independent strides. The best unverified candidate is model RH 130-157 (0.9009 s). The best available partial sweep is RH 138-157 (0.6340 s).','',
'What a complete cycle means here',
'A defensible anatomical cycle requires the same physical paw returning to the same phase, with its movement and identity observable across the interval. We search raw model X trajectories for two successive same-type extrema with an opposite extremum between them. A complete numerical oscillation is not sufficient to establish anatomical identity, touchdown, stance, swing, or whole-body walking phase. A single-paw cycle does not inherently require all other paws visible, but missing partner data prevents a full identity audit here; a four-paw demonstration additionally needs their trajectories.','',
'Input provenance verified',
'Before analysis, all 165 frame indices and timestamps and all 660 paw positions/availability entries must agree exactly between results.json, normalized-paws.csv, and temporal-audit.json. The actual prediction JSON SHA-256 must match both saved source hashes. Divergent or stale artifacts stop the analysis; no reconciliation or repair is performed. Tests cover coordinate divergence, stale hashes, and truncated CSV input.',
'',
'Existing code reused',
'Imported gait_engine/gait.py _sample_step and _peak_intervals, and its named peak rules: prominence >=0.15 body lengths, same-type peak spacing >=0.4 s, intervals 0.4-2.5 s. These remain unvalidated placeholder cutoffs. Each helper call receives a finite, genuinely consecutive run of the existing normalized X signal. Minima are detected by applying the same logic to -X, explicitly yielding an alternative phase convention.',
'The existing signal is (paw - neck/tail midpoint)/frame neck-tail distance in IMAGE axes. It is not the production shoulder/hip-relative, body-axis-projected signal. compute_gait_metrics, foot_strike_frames, and _prepare_points were not called: those paths fill gaps/smooth and use different gating/reference conventions. No production code was changed.','',
'Candidate cycle intervals with NO selected-paw gaps',
'Paw | Phase endpoints | Frames | Saved times (s) | Elapsed (s) | Why not reliable']
for c in complete:
    flags='; '.join(f"{x['fromFrame']}->{x['toFrame']} ({','.join(x['flags'])})" for x in c['pairAuditFlags'])
    missing='; '.join(p+':'+','.join(map(str,v)) for p,v in c['allPawMissingFrames'].items() if v)
    why=(flags or 'No positive hind-pair flags')+f"; partner audit unassessed on {len(c['pairAuditUncheckedEdges'])} edges; missing paws: {missing}; anatomical identity/contact not verified"
    lines.append(f"RH | {c['eventType']} | {c['startFrame']}-{c['endFrame']} | {c['startSeconds']:.4f}-{c['endSeconds']:.4f} | {c['durationSeconds']:.4f} | {why}")
lines += ['',
'The 63-84 candidate crosses the suspected 65->66 swap, plus 68->69 overlap. The 71-93 candidate crosses overlaps at 87->88,88->89,89->90. They are not used as trustworthy demonstrations. Other candidate intervals that cross gaps (including those spanning 21->22) remain explicitly rejected in cycle-analysis.json; no missing data was bridged or labels changed.',
'', 'Best candidate 130-157: verified numerical findings',
'- Model RH is above the existing paw threshold and has valid normalized X/Y at all 28 frames.',
'- Rearward minimum at frame 130, 4.3377 s; forward maximum at 138, 4.6046 s; rearward minimum at 157, 5.2386 s.',
'- Candidate phase durations: 130->138 = 0.2669 s; 138->157 = 0.6340 s; 130->157 = 0.9009 s.',
'- RH has no positive hind-pair identity flag inside this interval. This is NOT a clean bill of identity: LH is missing at 134 and 148, so edges 133->134,134->135,147->148,148->149 are unassessable.',
'- LF and RF additionally fail at 137. There is no uninterrupted four-paw track over the proposed cycle.',
'- The maximum simultaneous four-paw track anywhere in the clip is only 13 frames (149-161), spanning 0.4004 s, and no complete accepted raw cycle is contained in a four-paw uninterrupted segment.',
'- No ground-truth identity/contact annotations have been used; the previously reported uncertainty about anatomical left/right remains unresolved.',
'', 'Visual inspection, not verified ground truth',
'I inspected original and annotated representative frames 130,134,137,138,142,148,152,157. A hind foot appears to move through a plausible forward/backward pattern, but near/far hind feet converge in some views; this does not verify physical side identity. The dog turns toward the camera toward the end, so image-axis motion and projected body length are affected by perspective.',
'The model neck-tail length changes from 81.60 pixels at 130 to 66.39 at 157 (about 18.6% shorter). This is a measurement of the predicted reference, not proof of a real body-length change. Consequently, normalized excursions and X extrema may reflect view/reference changes as well as limb motion.','',
'Best available partial: 138-157',
'The RH maximum-to-minimum sweep lasts 0.6340 s and contains 20 real frames. Its RH coordinates remain available, with no coordinate correction or imputation. LH is unavailable at 148 and two hind-pair transitions cannot be audited. This demonstrates a raw tracked sweep, not a validated stance phase, foot contact sequence, or reliable full stride.',
'', 'Candidate step/event timings',
'All 27 detected phase extrema for all four model-labeled paws are in candidate-events.csv, with frame number, saved timestamp, normalized coordinates, and peak prominence. There are 20 same-phase interval candidates; 17 contain selected-paw gaps and/or lack a complete internal oscillation. These are candidate kinematic phase landmarks, NOT measured footfalls or step counts.',
'Peak detection uses source-frame timestamps, without subframe fitting. The nominal frame interval is about 0.0334 s; exact ground-contact time and statistical timing error have not been established. The 28-frame video playback lasts about 0.9343 s because both endpoints are displayed; the extrema elapsed time is 0.9009 s. Looping the preview repeats the same observation, not additional cycles.','',
'What is dependable versus experimental',
'- Reproducible numerical observations: which saved predictions pass thresholds; missing frame indices; raw normalized coordinates; source timestamps; event-frame arithmetic; audit flags/skipped edges. These are properties of model output, not verified anatomical truth.',
'- Experimental: phase extrema selection, inferred same-paw recurrence, normalized excursion interpretation, and candidate cycle duration as a biological quantity.',
'- Not measured/established: verified ground contacts, true step/stride counts, stride length in meters, limb symmetry, cadence, stance/swing durations, clinical gait quality, or limping. A normalized paw range is not automatically stride length.',
'', 'Files',
'- index.html: annotated H.264 video, raw trajectory plots, and contact sheets.',
'- walking-cycle-candidate.mp4: real frames 130-157 at original speed, raw keypoints, rejected points, and a time cursor.',
'- best-partial-cycle.mp4: real frames 138-157 only.',
'- full-trajectories.png/.svg: complete clip with gaps preserved and suspected swap markers.',
'- candidate-detail.png/.svg: candidate X/Y traces and explicit hind-pair audit coverage.',
'- original-contact-sheet.jpg and candidate-contact-sheet.jpg: visual inspection examples.',
'- cycle-analysis.json: every candidate, missing frame, identity flag, and exclusion reason.',
'- candidate-events.csv: all candidate phase-event timings.',
'- selected-phase-timings.csv: the three phase landmarks in the selected RH candidate.',
'- candidate-intervals.csv: every interval and its complete-raw-versus-reliable status.',
'- render-manifest.json: original hashes and decoded output-frame counts.',
'', 'Reproduce from repository root',
'PYTHONDONTWRITEBYTECODE=1 python tmp/rtmpose-test/paw-tracking-experiment/walking-cycle/analyze_cycles.py',
'PYTHONDONTWRITEBYTECODE=1 python tmp/rtmpose-test/paw-tracking-experiment/walking-cycle/render_cycles.py',
'PYTHONDONTWRITEBYTECODE=1 python tmp/rtmpose-test/paw-tracking-experiment/walking-cycle/write_report.py',
'PYTHONDONTWRITEBYTECODE=1 python -m unittest discover -s tmp/rtmpose-test/paw-tracking-experiment/walking-cycle -p test_cycles.py -v',
'', 'Opening in Codespaces',
'Run: python -m http.server 8011 --bind 0.0.0.0 --directory tmp/rtmpose-test/paw-tracking-experiment/walking-cycle',
'Open private port 8011 from the Ports tab. The gallery uses H.264/yuv420p and works without external services. For video inspection, pause or reduce playback speed in the browser controls.',
'', 'Tests and dependencies',
'12 reproducible tests passed: synthetic complete oscillation/timing, confidence gap preservation, missing source frame, swap exclusion, missing partner audit coverage, absent audit rows, monotonic partial motion, no production interpolation path, invalid time/duplicate handling, and saved-clip candidate regression. These establish algorithm behavior, not biological accuracy.',
'Tools were installed only under ../walking-cycle-tools. Version pins are in requirements-cycle-tools.txt; reinstall with: python -m pip install --target tmp/rtmpose-test/paw-tracking-experiment/walking-cycle-tools -r tmp/rtmpose-test/paw-tracking-experiment/walking-cycle/requirements-cycle-tools.txt',
'', 'Next defensible step',
'Manually annotate physical paw identity/visibility and candidate contact events in frames 130-157, especially 134,137,148, or acquire a clearer continuous side-view sequence if identities cannot be resolved. Confirm at least one same-paw recurrence before calling it a complete gait cycle. Evaluate fixed event/identity rules on separate labeled clips before reporting gait measurements.','']
(HERE/'report.txt').write_text('\n'.join(lines))
with (HERE/'candidate-intervals.csv').open('w',newline='') as out:
    fields=['paw','eventType','startFrame','endFrame','durationSeconds','completeRawOscillation','reliableWalkingCycle','selectedPawMissingFrames','reliabilityBlockers'];w=csv.DictWriter(out,fieldnames=fields);w.writeheader()
    for c in r['candidates']:w.writerow({key:';'.join(map(str,c[key])) if isinstance(c[key],list) else c[key] for key in fields})
selected_frames={best['startFrame'],best['endFrame']}|{e['frameIndex'] for e in best['oppositeEventsInside']}
selected_events=sorted([e for e in r['events'] if e['paw']==best['paw'] and e['frameIndex'] in selected_frames],key=lambda e:e['frameIndex'])
with (HERE/'selected-phase-timings.csv').open('w',newline='') as out:
    w=csv.DictWriter(out,fieldnames=['paw','eventType','frameIndex','timeSeconds']);w.writeheader()
    w.writerows({k:e[k] for k in w.fieldnames} for e in selected_events)
versions=sorted(f'{d.metadata["Name"]}=={d.version}' for d in importlib.metadata.distributions(path=[str(EXPERIMENT/'walking-cycle-tools')]))
(HERE/'requirements-cycle-tools.txt').write_text('\n'.join(versions)+'\n')
response='''No complete reliable anatomical walking cycle can yet be established.

Best unverified raw candidate: model-labeled right hind paw, frames 130-157 (0.9009 seconds).
Best available partial sweep: frames 138-157 (0.6340 seconds).

Why it remains unverified: LH is missing at 134 and 148, both front paws fail at 137, four hind-pair transitions cannot be audited, anatomical identity is uncertain, and the dog turns toward the camera. Other complete raw oscillations cross the suspected 65-66 swap or hind-paw overlap flags.

Generated an annotated H.264 MP4, a separate partial-sweep MP4, trajectory plots, original/annotated contact sheets, candidate phase timings, and a report distinguishing reproducible model-output measurements from unvalidated gait interpretations. Candidate extrema are not foot contacts.

12 reproducible tests passed. Existing gait.py timing/peak helpers were reused without its gap filling or smoothing. No coordinates, identities, confidence thresholds, production code, or saved human annotations were changed.

Open gallery: tmp/rtmpose-test/paw-tracking-experiment/walking-cycle/index.html
Full report: tmp/rtmpose-test/paw-tracking-experiment/walking-cycle/report.txt
Partial video: tmp/rtmpose-test/paw-tracking-experiment/walking-cycle/best-partial-cycle.mp4
Candidate video: tmp/rtmpose-test/paw-tracking-experiment/walking-cycle/walking-cycle-candidate.mp4

Next: manually verify the physical paw and phase/contact events in 130-157, or use clearer side-view footage if identity remains unresolved.
'''
(EXPERIMENT/'PetLens-architecture-review.txt').write_text(response)
(HERE/'PetLens-architecture-review.txt').write_text(response)
print('Wrote detailed report, candidate interval CSV, dependency versions, and response text inside experiment.')
