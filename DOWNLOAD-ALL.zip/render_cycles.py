"""Annotated raw-cycle candidate/partial demonstration; all conclusions provisional."""
from pathlib import Path
import csv
import hashlib
import json
import os
import sys
import subprocess
HERE=Path(__file__).resolve().parent;EXPERIMENT=HERE.parent;ROOT=EXPERIMENT.parents[2]
sys.path.insert(0,str(EXPERIMENT/'walking-cycle-tools'))
os.environ['MPLCONFIGDIR']=str(HERE/'plot-cache')
import cv2
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import imageio_ffmpeg

PAWS=['left_front_paw','right_front_paw','left_back_paw','right_back_paw']
SHORT=['LF','RF','LH','RH'];COLORS=['#269b32','#007ec1','#bb2ea6','#e06d00']
BGR=[(50,210,50),(255,190,40),(230,80,230),(30,140,255)]


def put(img,text,pos,color=(240,240,240),scale=.58):
    (w,h),baseline=cv2.getTextSize(text,cv2.FONT_HERSHEY_SIMPLEX,scale,1)
    cv2.rectangle(img,(pos[0]-2,pos[1]-h-3),(pos[0]+w+2,pos[1]+baseline+2),(24,24,24),-1)
    cv2.putText(img,text,pos,cv2.FONT_HERSHEY_SIMPLEX,scale,color,1,cv2.LINE_AA)


def main():
    rawdata=json.loads((EXPERIMENT/'results.json').read_text());frames=rawdata['frames']
    analysis=json.loads((HERE/'cycle-analysis.json').read_text())
    audit=json.loads((EXPERIMENT/'temporal-audit.json').read_text())
    sourcepath=EXPERIMENT.parent/'full-video/rtdetr-rtmpose-full-video.json'
    predictions=json.loads(sourcepath.read_text());video=ROOT/predictions['video']
    sources=[video,sourcepath,ROOT/'gait_engine/gait.py',EXPERIMENT/'results.json',EXPERIMENT/'temporal-audit.json']
    before={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources}
    times=np.array([f['timestampSeconds'] for f in frames])
    best=analysis['bestUnverifiedRawCycle'];partial=analysis['bestPartialCycle']
    assert best and partial
    start,end=best['startFrame'],best['endFrame']
    values={axis:{paw:np.array([f['paws'][paw][axis] if f['paws'][paw]['usable'] else np.nan for f in frames]) for paw in PAWS} for axis in ('x','y')}
    fig,axes=plt.subplots(2,1,figsize=(13,7),sharex=True,layout='constrained')
    for axis,ax in zip(('x','y'),axes):
        for paw,label,color in zip(PAWS,SHORT,COLORS):ax.plot(times,values[axis][paw],'.-',ms=3,lw=1,color=color,label=label)
        ax.axvspan(best['startSeconds'],best['endSeconds'],color='green',alpha=.08,label='unverified RH cycle candidate')
        for f in [21,65]:ax.axvline((times[f]+times[f+1])/2,color='red',ls='--',lw=1)
        ax.set_ylabel(f'Normalized {axis.upper()} (body lengths)');ax.grid(alpha=.2)
    axes[0].legend(ncol=5,fontsize=8);axes[0].set_title('Raw confidence-filtered trajectories: missing values remain gaps; red = suspected hind swaps')
    axes[1].set_xlabel('Saved video time (seconds)');fig.savefig(HERE/'full-trajectories.png',dpi=160);fig.savefig(HERE/'full-trajectories.svg');plt.close(fig)
    fig,axes=plt.subplots(3,1,figsize=(12,8),sharex=True,layout='constrained',height_ratios=[2,2,1])
    for axis,ax in zip(('x','y'),axes[:2]):
        for paw,label,color in zip(PAWS,SHORT,COLORS):ax.plot(times[start:end+1],values[axis][paw][start:end+1],'.-',color=color,label=label)
        for e in [e for e in analysis['events'] if e['paw']==best['paw'] and start<=e['frameIndex']<=end]:
            ax.axvline(e['timeSeconds'],color='black',ls=':',lw=.8)
        ax.set_ylabel(f'Normalized {axis.upper()}');ax.grid(alpha=.2)
    axes[0].legend(ncol=4);axes[0].set_title('Unverified RH oscillation 130–157; conservative partial sweep 138–157')
    for row in audit['comparisons']:
        if row['pair']=='hind' and start<=row['fromFrame'] and row['toFrame']<=end:
            axes[2].plot([row['fromSeconds'],row['toSeconds']],[0,0],lw=10,color='gray' if not row['eligible'] else 'orange' if row['flags'] else 'green',solid_capstyle='butt')
    axes[2].set_yticks([0],['Hind-pair audit']);axes[2].set_ylim(-1,1);axes[2].set_xlabel('Saved video time (seconds); green = assessed/unflagged, gray = unassessable')
    fig.savefig(HERE/'candidate-detail.png',dpi=160);fig.savefig(HERE/'candidate-detail.svg');plt.close(fig)
    # Fixed raw plot; cursor marks observed frame timestamps, no generated paw samples.
    fig,ax=plt.subplots(figsize=(12.8,2.8),dpi=100,layout='constrained')
    for paw,label,color in zip(PAWS,SHORT,COLORS):ax.plot(times[start:end+1],values['x'][paw][start:end+1],'.-',color=color,label=label,ms=4)
    cursor=ax.axvline(times[start],color='black',lw=1);ax.set_ylabel('Normalized X');ax.set_xlabel('Original video seconds');ax.legend(ncol=4,loc='upper right',fontsize=8);ax.grid(alpha=.2)
    cap=cv2.VideoCapture(str(video));source_frames={};i=0
    while True:
        ok,img=cap.read()
        if not ok:break
        if start<=i<=end:source_frames[i]=img
        i+=1
    cap.release();assert len(source_frames)==end-start+1
    out=HERE/'walking-cycle-candidate.mp4'
    writer=imageio_ffmpeg.write_frames(str(out),(1280,900),fps=predictions['fps'],codec='libx264',pix_fmt_in='rgb24',pix_fmt_out='yuv420p',quality=8,macro_block_size=1,output_params=['-movflags','+faststart'])
    writer.send(None)
    contacts=[];selected=[130,134,137,138,142,148,152,157]
    originals=[]
    for index in range(start,end+1):
        raw=source_frames[index];rec=predictions['frames'][index];lookup={p['name']:p for p in rec.get('keypoints',[])}
        canvas=np.full((900,1280,3),24,np.uint8)
        put(canvas,'UNVERIFIED RH CYCLE CANDIDATE 130-157 | partial sweep 138-157',(16,28),scale=.70)
        put(canvas,f'Frame {index} / {times[index]:.4f} s | no repairs, smoothing, or interpolation',(16,58),scale=.65)
        canvas[80:560,:852]=cv2.resize(raw,(852,480),interpolation=cv2.INTER_CUBIC)
        for paw,label,color in zip(PAWS,SHORT,BGR):
            q=lookup.get(paw)
            if not q:continue
            pos=(round(q['x']*2),80+round(q['y']*2));usable=frames[index]['paws'][paw]['usable']
            if usable:cv2.circle(canvas,pos,7,color,-1,cv2.LINE_AA)
            else:cv2.drawMarker(canvas,pos,color,cv2.MARKER_TILTED_CROSS,18,3,cv2.LINE_AA)
            put(canvas,label+(' LOW/MISSING' if not usable else ''),(pos[0]+8,pos[1]+(-15 if label in ('LF','LH') else 24)),color,.50)
            if label=='RH':cv2.circle(canvas,pos,12,(255,255,255),2,cv2.LINE_AA)
        ref=frames[index]['reference']
        if ref:cv2.drawMarker(canvas,(round(ref['centerX']*2),80+round(ref['centerY']*2)),(255,255,0),cv2.MARKER_DIAMOND,14,2)
        lines=['Model RH: continuously present','Anatomical identity: unverified','Full four-paw cycle: not established','RH extrema (not foot contacts):','130: rearward, 4.3377 s','138: forward, 4.6046 s','157: rearward, 5.2386 s','LH missing at 134 and 148','LF/RF missing at 137','Circles: accepted; X: rejected','White ring: model RH','Cyan diamond: body center']
        for j,line in enumerate(lines):put(canvas,line,(865,105+j*33),scale=.48)
        cursor.set_xdata([times[index],times[index]]);fig.canvas.draw()
        plot=np.asarray(fig.canvas.buffer_rgba())[:,:,:3]
        canvas[600:880,:1280]=cv2.cvtColor(plot,cv2.COLOR_RGB2BGR)
        put(canvas,'Timing is candidate paw-X phase timing. Ground contact, stride length, and gait health are not measured.',(16,586),scale=.58)
        writer.send(cv2.cvtColor(canvas,cv2.COLOR_BGR2RGB))
        if index in selected:
            cv2.imwrite(str(HERE/f'candidate-frame-{index:03d}.jpg'),canvas,[cv2.IMWRITE_JPEG_QUALITY,95]);contacts.append(cv2.resize(canvas,(640,450)))
            orig=cv2.resize(raw,(852,480));label=np.full((520,852,3),24,np.uint8);label[40:]=orig;put(label,f'Original frame {index}',(15,27));originals.append(label)
    writer.close();plt.close(fig)
    partial_out=HERE/'best-partial-cycle.mp4'
    offset=partial['startFrame']-start
    subprocess.run([imageio_ffmpeg.get_ffmpeg_exe(),'-v','error','-y','-i',str(out),'-vf',f'trim=start_frame={offset}:end_frame={end-start+1},setpts=PTS-STARTPTS','-r',str(predictions['fps']),'-c:v','libx264','-pix_fmt','yuv420p','-crf','18','-movflags','+faststart',str(partial_out)],check=True)
    pc=cv2.VideoCapture(str(partial_out));partial_count=0
    while True:
        ok,_=pc.read()
        if not ok:break
        partial_count+=1
    pc.release();assert partial_count==partial['endFrame']-partial['startFrame']+1
    cv2.imwrite(str(HERE/'candidate-contact-sheet.jpg'),np.vstack([np.hstack(contacts[i:i+2]) for i in range(0,len(contacts),2)]))
    cv2.imwrite(str(HERE/'original-contact-sheet.jpg'),np.vstack([np.hstack(originals[i:i+2]) for i in range(0,len(originals),2)]))
    check=cv2.VideoCapture(str(out));decoded=0
    while True:
        ok,img=check.read()
        if not ok:break
        decoded+=1
    check.release();assert decoded==end-start+1
    assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in before.items())
    (HERE/'render-manifest.json').write_text(json.dumps({'sourceHashes':before,'renderedSourceFrames':[start,end],'outputFrameCountVerified':decoded,'partialSourceFrames':[partial['startFrame'],partial['endFrame']],'partialFrameCountVerified':partial_count,'fps':predictions['fps'],'codec':'H.264/yuv420p','extremaElapsedSeconds':best['durationSeconds'],'videoPlaybackDurationSeconds':decoded/predictions['fps'],'note':'Playback includes both endpoint frames; extrema timing is last timestamp minus first.'},indent=2)+'\n')
    html='<!doctype html><html lang="en"><meta charset="utf-8"><title>PetLens walking-cycle candidates</title><body style="font-family:system-ui;max-width:1300px;margin:auto"><h1>Walking-cycle candidate, not a verified gait cycle</h1><p>RH raw oscillation 130–157; best partial sweep 138–157. No coordinates repaired or imputed.</p><p><a href="report.txt">Report and candidate timings</a> | <a href="candidate-events.csv">All event timings</a> | <a href="cycle-analysis.json">Candidate exclusions</a></p><video controls loop style="width:100%" src="walking-cycle-candidate.mp4"></video><p><a href="walking-cycle-candidate.mp4">Download candidate H.264 MP4</a> | <a href="best-partial-cycle.mp4">Download best partial sweep MP4 (138–157)</a>. Normal source speed; pausing/slower playback helps inspect. Looping the preview repeats the same frames, not additional observed cycles.</p>'
    for filename in ['full-trajectories.png','candidate-detail.png','original-contact-sheet.jpg','candidate-contact-sheet.jpg']:
        html+=f'<h2>{filename}</h2><a href="{filename}"><img style="width:100%" src="{filename}" alt="{filename}"></a>'
    (HERE/'index.html').write_text(html+'</body></html>')
    print('Wrote H.264 visualization, raw graphs, original/annotated contact sheets. Verified',decoded,'frames; source hashes unchanged.')

if __name__=='__main__':main()
