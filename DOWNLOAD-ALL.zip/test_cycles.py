"""Synthetic algorithm tests plus regression checks; no invented real-dog truth."""
import copy
import json
import math
from pathlib import Path
import unittest
import tempfile
from unittest.mock import patch
from analyze_cycles import analyze,contiguous_runs,inspect_interval,validate_inputs,PAWS


def synthetic(count=151):
    fs=[]
    for i in range(count):
        x=-.3*math.cos(2*math.pi*i/30)
        fs.append({'frameIndex':i,'timestampSeconds':i/30,
                   'paws':{p:{'usable':True,'x':x,'y':.7+.05*math.sin(2*math.pi*i/30)} for p in PAWS}})
    comparisons=[{'pair':pair,'fromFrame':i,'toFrame':i+1,'eligible':True,'flags':[],'skipReasons':[]} for i in range(count-1) for pair in ('front','hind')]
    return fs,comparisons


class CycleTests(unittest.TestCase):
    def test_saved_artifacts_agree_exactly(self):
        p=Path(__file__).resolve().parent.parent
        data=json.loads((p/'results.json').read_text())
        audit=json.loads((p/'temporal-audit.json').read_text())
        result=validate_inputs(data,audit,p/'normalized-paws.csv',p.parent/'full-video/rtdetr-rtmpose-full-video.json')
        self.assertEqual(result['pawPositionsChecked'],660)

    def test_stale_or_modified_artifacts_fail_closed(self):
        p=Path(__file__).resolve().parent.parent
        data=json.loads((p/'results.json').read_text())
        audit=json.loads((p/'temporal-audit.json').read_text())
        prediction=p.parent/'full-video/rtdetr-rtmpose-full-video.json'
        altered=copy.deepcopy(data);altered['frames'][0]['paws'][PAWS[0]]['x']+=.01
        with self.assertRaisesRegex(ValueError,'coordinate mismatch'):
            validate_inputs(altered,audit,p/'normalized-paws.csv',prediction)
        altered=copy.deepcopy(audit);altered['sourceSha256']='stale'
        with self.assertRaisesRegex(ValueError,'hash mismatch'):
            validate_inputs(data,altered,p/'normalized-paws.csv',prediction)
        with tempfile.TemporaryDirectory() as directory:
            truncated=Path(directory)/'normalized.csv'
            truncated.write_text((p/'normalized-paws.csv').read_text().splitlines()[0]+'\n')
            with self.assertRaisesRegex(ValueError,'frame counts'):
                validate_inputs(data,audit,truncated,prediction)

    def test_complete_raw_sinusoid_and_exact_timing(self):
        frames,audit=synthetic();r=analyze(frames,audit)
        complete=[c for c in r['candidates'] if c['completeRawOscillation']]
        self.assertTrue(complete)
        self.assertTrue(all(abs(c['durationSeconds']-1)<1e-9 for c in complete))
        self.assertTrue(all(not c['reliableWalkingCycle'] for c in complete))
        self.assertTrue(all('anatomical_paw_identity_and_cycle_events_not_human_verified' in c['reliabilityBlockers'] for c in complete))

    def test_low_confidence_gap_stays_missing(self):
        fs,au=synthetic();fs[30]['paws'][PAWS[3]]={'usable':False,'x':None,'y':None}
        snapshot=copy.deepcopy(fs);check=inspect_interval(fs,au,PAWS[3],15,45)
        self.assertEqual(check['selectedPawMissingFrames'],[30])
        runs=contiguous_runs(fs,PAWS[3]);self.assertFalse(any(run[0]['frameIndex']<30<run[-1]['frameIndex'] for run in runs))
        r=analyze(fs,au)
        self.assertFalse(any(c['completeRawOscillation'] and c['paw']==PAWS[3] and c['startFrame']<=30<=c['endFrame'] for c in r['candidates']))
        self.assertEqual(fs,snapshot)

    def test_missing_source_frame_not_compressed(self):
        fs,au=synthetic();fs=[f for f in fs if f['frameIndex']!=30]
        result=inspect_interval(fs,au,PAWS[3],15,45)
        self.assertFalse(result['timestampsContinuous']);self.assertEqual(result['selectedPawMissingFrames'],[30])
        self.assertFalse(any(run[0]['frameIndex']<30<run[-1]['frameIndex'] for run in contiguous_runs(fs,PAWS[3])))

    def test_identity_swap_flags_block_reliability(self):
        fs,au=synthetic();row=next(r for r in au if r['pair']=='hind' and r['fromFrame']==21);row['flags']=['possible_identity_swap']
        check=inspect_interval(fs,au,PAWS[3],15,45)
        self.assertEqual(check['pairAuditFlags'][0]['fromFrame'],21)
        self.assertIn('selected_pair_has_temporal_identity_or_overlap_flags',check['reliabilityBlockers'])

    def test_missing_partner_is_not_false_clean_audit(self):
        fs,au=synthetic();fs[25]['paws'][PAWS[2]]={'usable':False,'x':None,'y':None}
        row=next(r for r in au if r['pair']=='hind' and r['fromFrame']==24);row['eligible']=False;row['skipReasons']=['partner absent']
        check=inspect_interval(fs,au,PAWS[3],15,45)
        self.assertEqual(check['selectedPawMissingFrames'],[])
        self.assertEqual(check['allPawMissingFrames'][PAWS[2]],[25])
        self.assertTrue(check['pairAuditUncheckedEdges'])

    def test_absent_audit_rows_are_unassessed(self):
        fs,_=synthetic();check=inspect_interval(fs,[],PAWS[3],15,45)
        self.assertEqual(len(check['pairAuditUncheckedEdges']),30)

    def test_monotonic_motion_is_partial_not_full_cycle(self):
        fs,au=synthetic()
        for f in fs:
            for p in PAWS:f['paws'][p]['x']=f['frameIndex']/100
        self.assertFalse(analyze(fs,au)['candidates'])

    def test_no_production_interpolation_or_smoothing_entrypoint(self):
        fs,au=synthetic();snapshot=copy.deepcopy(fs)
        with patch('gait_engine.gait._prepare_points',side_effect=AssertionError('must not preprocess')):
            analyze(fs,au)
        self.assertEqual(fs,snapshot)

    def test_invalid_time_splits_and_duplicate_frames_rejected(self):
        fs,au=synthetic();fs[30]['timestampSeconds']=float('nan')
        self.assertFalse(any(any(f['frameIndex']==30 for f in run) for run in contiguous_runs(fs,PAWS[3])))
        with self.assertRaises(ValueError):analyze([fs[0],fs[0]],au)

    def test_saved_clip_candidate_and_blocker_regression(self):
        p=Path(__file__).resolve().parent.parent
        fs=json.loads((p/'results.json').read_text())['frames'];au=json.loads((p/'temporal-audit.json').read_text())['comparisons']
        r=analyze(fs,au)
        complete={(c['paw'],c['startFrame'],c['endFrame']) for c in r['candidates'] if c['completeRawOscillation']}
        self.assertEqual(complete,{('right_back_paw',63,84),('right_back_paw',71,93),('right_back_paw',130,157)})
        self.assertEqual(r['bestUnverifiedRawCycle']['startFrame'],130)
        self.assertEqual(r['bestPartialCycle']['startFrame'],138)
        self.assertAlmostEqual(r['bestPartialCycle']['durationSeconds'],.634)
        self.assertTrue(all(not c['reliableWalkingCycle'] for c in r['candidates']))

if __name__=='__main__':unittest.main()
