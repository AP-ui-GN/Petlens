"""Raw, confidence-filtered paw-cycle candidates; no repairs or clinical metrics."""
from __future__ import annotations
import hashlib
import json
import math
import os
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
EXPERIMENT=HERE.parent
ROOT=EXPERIMENT.parents[2]
sys.path.insert(0,str(EXPERIMENT/'walking-cycle-tools'))
sys.path.insert(0,str(ROOT))
os.environ.setdefault('MPLCONFIGDIR',str(HERE/'plot-cache'))
import numpy as np
from scipy.signal import find_peaks
from gait_engine.gait import (_peak_intervals,_sample_step,PEAK_PROMINENCE_BODY_LENGTHS,
    MIN_PEAK_SPACING_SECONDS,STRIDE_INTERVAL_MIN_SECONDS,STRIDE_INTERVAL_MAX_SECONDS)

PAWS=['left_front_paw','right_front_paw','left_back_paw','right_back_paw']


def validate_inputs(data, audit, csv_path, prediction_path):
    """Fail closed on stale artifacts; never reconcile divergent measurements."""
    import csv
    digest=hashlib.sha256(prediction_path.read_bytes()).hexdigest()
    if data['sourceSha256']!=digest or audit['sourceSha256']!=digest:
        raise ValueError('Prediction source hash mismatch')
    with csv_path.open(newline='') as stream:
        rows=list(csv.DictReader(stream))
    frames=data['frames']; normalized=audit['normalizedFrames']
    if not len(rows)==len(frames)==len(normalized)==data['totalFrames']:
        raise ValueError('Normalized artifact frame counts differ')
    for frame, row, audited in zip(frames, rows, normalized):
        index=frame['frameIndex']
        if index!=int(row['frameIndex']) or index!=audited['frameIndex']:
            raise ValueError('Normalized artifact frame indices differ')
        if frame['timestampSeconds']!=float(row['timestampSeconds']) or frame['timestampSeconds']!=audited['timestampSeconds']:
            raise ValueError('Normalized artifact timestamps differ')
        for paw in PAWS:
            point=frame['paws'][paw]; position=audited['paws'][paw]['position']
            usable=point['usable']
            if usable!=(row[paw+'_usable']=='True') or usable!=(position is not None):
                raise ValueError(f'Normalized availability mismatch: {index} {paw}')
            for axis, component in enumerate(('x','y')):
                value=point[component]; cell=row[paw+'_'+component]
                if usable:
                    if value!=float(cell) or value!=position[axis]:
                        raise ValueError(f'Normalized coordinate mismatch: {index} {paw}')
                elif value is not None or cell!='':
                    raise ValueError(f'Missing coordinate was populated: {index} {paw}')
    return {'framesChecked':len(frames),'pawPositionsChecked':len(frames)*len(PAWS),
            'agreement':'exact coordinates, availability, indices, timestamps',
            'predictionSha256':digest}


def finite_position(f,paw):
    v=f['paws'][paw]
    return bool(v['usable'] and all(isinstance(v.get(k),(int,float)) and math.isfinite(v[k]) for k in ('x','y')))


def contiguous_runs(frames,paw):
    runs=[];current=[]
    for f in sorted(frames,key=lambda f:f['frameIndex']):
        good=finite_position(f,paw) and isinstance(f.get('timestampSeconds'),(int,float)) and math.isfinite(f['timestampSeconds'])
        adjacent=bool(current and f['frameIndex']==current[-1]['frameIndex']+1 and math.isfinite(f['timestampSeconds']) and f['timestampSeconds']>current[-1]['timestampSeconds'])
        if not good or (current and not adjacent):
            if current:runs.append(current);current=[]
        if good:current.append(f)
    if current:runs.append(current)
    return runs


def inspect_interval(frames,comparisons,paw,start,end):
    selected=[f for f in frames if start<=f['frameIndex']<=end]
    lookup={f['frameIndex']:f for f in selected}
    own_missing=[i for i in range(start,end+1) if i not in lookup or not finite_position(lookup[i],paw)]
    all_missing={p:[i for i in range(start,end+1) if i not in lookup or not finite_position(lookup[i],p)] for p in PAWS}
    pair='front' if 'front' in paw else 'hind'
    # Only edges completely within the interval are relevant, including an edge ending at end.
    edges=[r for r in comparisons if r['pair']==pair and start<=r['fromFrame'] and r['toFrame']<=end]
    flags=[{'fromFrame':r['fromFrame'],'toFrame':r['toFrame'],'flags':r['flags']} for r in edges if r['flags']]
    unchecked=[{'fromFrame':r['fromFrame'],'toFrame':r['toFrame'],'reasons':r['skipReasons']} for r in edges if not r['eligible']]
    present={(r['fromFrame'],r['toFrame']) for r in edges}
    unchecked.extend({'fromFrame':i,'toFrame':i+1,'reasons':['audit_comparison_missing']} for i in range(start,end) if (i,i+1) not in present)
    clock_ok=all(i in lookup and i+1 in lookup and lookup[i+1]['timestampSeconds']>lookup[i]['timestampSeconds'] for i in range(start,end))
    reasons=[]
    if own_missing:reasons.append('selected_paw_has_missing_or_low_confidence_frames')
    if not clock_ok:reasons.append('missing_source_frames_or_nonincreasing_time')
    if flags:reasons.append('selected_pair_has_temporal_identity_or_overlap_flags')
    if unchecked:reasons.append('selected_pair_identity_audit_cannot_assess_every_edge')
    if any(all_missing.values()):reasons.append('four_paw_coverage_incomplete')
    reasons.append('anatomical_paw_identity_and_cycle_events_not_human_verified')
    return {'selectedPawMissingFrames':own_missing,'allPawMissingFrames':all_missing,'pairAuditFlags':flags,
            'pairAuditUncheckedEdges':unchecked,'timestampsContinuous':clock_ok,'reliabilityBlockers':reasons}


def analyze(frames,comparisons):
    if len({f['frameIndex'] for f in frames})!=len(frames):raise ValueError('Duplicate frames')
    events=[];helper_intervals=[]
    for paw in PAWS:
        for run in contiguous_runs(frames,paw):
            if len(run)<5:continue
            stamps=np.array([f['timestampSeconds'] for f in run],dtype=float)
            x=np.array([f['paws'][paw]['x'] for f in run],dtype=float)
            step=_sample_step(stamps)
            if step is None:continue
            for kind,sign in [('forward_maximum',1),('rearward_minimum',-1)]:
                signal=sign*x
                peaks,properties=find_peaks(signal,prominence=PEAK_PROMINENCE_BODY_LENGTHS,
                                           distance=max(1,int(round(MIN_PEAK_SPACING_SECONDS/step))))
                kept,excursions=_peak_intervals(signal,stamps,step)
                helper_intervals.append({'paw':paw,'eventType':kind,'runStart':run[0]['frameIndex'],'runEnd':run[-1]['frameIndex'],
                                         'intervalSeconds':kept,'excursionBodyLengths':excursions})
                for i,prominence in zip(peaks,properties['prominences']):
                    f=run[int(i)]
                    events.append({'paw':paw,'eventType':kind,'frameIndex':f['frameIndex'],'timeSeconds':f['timestampSeconds'],
                                   'x':f['paws'][paw]['x'],'y':f['paws'][paw]['y'],'prominenceBodyLengths':float(prominence),
                                   'uninterruptedRun':[run[0]['frameIndex'],run[-1]['frameIndex']]})
    events.sort(key=lambda e:(e['paw'],e['eventType'],e['frameIndex']))
    candidates=[]
    for paw in PAWS:
        for kind in ('forward_maximum','rearward_minimum'):
            these=[e for e in events if e['paw']==paw and e['eventType']==kind]
            for a,b in zip(these,these[1:]):
                duration=b['timeSeconds']-a['timeSeconds']
                if not STRIDE_INTERVAL_MIN_SECONDS<=duration<=STRIDE_INTERVAL_MAX_SECONDS:continue
                checks=inspect_interval(frames,comparisons,paw,a['frameIndex'],b['frameIndex'])
                opposite=[e for e in events if e['paw']==paw and e['eventType']!=kind and a['frameIndex']<e['frameIndex']<b['frameIndex']]
                complete=bool(not checks['selectedPawMissingFrames'] and checks['timestampsContinuous'] and opposite)
                candidates.append({'paw':paw,'eventType':kind,'startFrame':a['frameIndex'],'endFrame':b['frameIndex'],
                                   'startSeconds':a['timeSeconds'],'endSeconds':b['timeSeconds'],'durationSeconds':duration,
                                   'oppositeEventsInside':opposite,'completeRawOscillation':complete,
                                   'reliableWalkingCycle':False,**checks})
    complete=[c for c in candidates if c['completeRawOscillation']]
    # Prefer candidates without selected-pair flags, then fewer unassessed audit edges.
    best=min(complete,key=lambda c:(len(c['pairAuditFlags']),len(c['pairAuditUncheckedEdges']),c['startFrame'])) if complete else None
    partial=None
    if best:
        middle=best['oppositeEventsInside'][-1]
        partial={'paw':best['paw'],'startFrame':middle['frameIndex'],'endFrame':best['endFrame'],
                 'startSeconds':middle['timeSeconds'],'endSeconds':best['endSeconds'],
                 'durationSeconds':best['endSeconds']-middle['timeSeconds'],
                 'description':'raw maximum-to-minimum sweep, a partial movement cycle; not a ground-contact interval',
                 **inspect_interval(frames,comparisons,best['paw'],middle['frameIndex'],best['endFrame'])}
    return {'events':events,'candidates':candidates,'helperIntervals':helper_intervals,'bestUnverifiedRawCycle':best,'bestPartialCycle':partial}


def main():
    source=EXPERIMENT/'results.json';audit_path=EXPERIMENT/'temporal-audit.json'
    csv_path=EXPERIMENT/'normalized-paws.csv'
    prediction_path=EXPERIMENT.parent/'full-video/rtdetr-rtmpose-full-video.json'
    hashes={str(f):hashlib.sha256(f.read_bytes()).hexdigest() for f in (source,audit_path,csv_path,prediction_path,ROOT/'gait_engine/gait.py')}
    data=json.loads(source.read_text());audit=json.loads(audit_path.read_text())
    validation=validate_inputs(data,audit,csv_path,prediction_path)
    result=analyze(data['frames'],audit['comparisons'])
    result.update(sourceHashes=hashes,inputValidation=validation,thresholds=data['thresholds'],frameCount=data['totalFrames'],
                  reliableWalkingCyclesEstablished=0,
                  gaitReuse={'functions':['_sample_step','_peak_intervals'],'prominenceBodyLengths':PEAK_PROMINENCE_BODY_LENGTHS,
                             'minimumPeakSpacingSeconds':MIN_PEAK_SPACING_SECONDS,'intervalSeconds':[STRIDE_INTERVAL_MIN_SECONDS,STRIDE_INTERVAL_MAX_SECONDS],
                             'signal':'existing body-center normalized image X (not the production shoulder/hip body-axis signal)',
                             'notCalled':['compute_gait_metrics','foot_strike_frames','_prepare_points'],
                             'reason':'those entry points interpolate/smooth and use different confidence/reference conventions; the helper is applied only within finite contiguous runs'},
                  noInterpolation=True,noSmoothing=True,noIdentityCorrections=True,
                  eventCaveat='Paw X extrema are candidate phase landmarks, not verified foot contacts or clinical step timings.')
    (HERE/'cycle-analysis.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    import csv
    with (HERE/'candidate-events.csv').open('w',newline='') as out:
        keys=['paw','eventType','frameIndex','timeSeconds','x','y','prominenceBodyLengths'];w=csv.DictWriter(out,fieldnames=keys);w.writeheader()
        for row in result['events']:w.writerow({k:row[k] for k in keys})
    assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in hashes.items())
    print('Complete raw oscillations:',[(c['paw'],c['startFrame'],c['endFrame'],c['durationSeconds']) for c in result['candidates'] if c['completeRawOscillation']])
    print('Best unverified raw cycle:',result['bestUnverifiedRawCycle'])
    print('Best partial:',result['bestPartialCycle'])

if __name__=='__main__':main()
