auto_scale_lr = dict(base_batch_size=4, enable=False)
backend_args = dict(backend='local')
base_lr = 0.004
codec = dict(
    input_size=(
        256,
        256,
    ),
    normalize=False,
    sigma=(
        5.66,
        5.66,
    ),
    simcc_split_ratio=2.0,
    type='SimCCLabel',
    use_dark=False)
custom_hooks = []
custom_imports = dict(
    allow_failed_imports=False,
    imports=[
        'training.rtmpose_paw_v2.components',
    ])
data_mode = 'topdown'
data_root = 'data/ap10k/'
dataset_type = 'AP10KDataset'
default_hooks = dict(
    badcase=dict(
        badcase_thr=5,
        enable=False,
        metric_type='loss',
        out_dir='badcase',
        type='BadCaseAnalysisHook'),
    checkpoint=dict(
        by_epoch=False,
        interval=100,
        max_keep_ckpts=1,
        save_last=True,
        type='CheckpointHook'),
    logger=dict(interval=10, type='LoggerHook'),
    param_scheduler=dict(type='ParamSchedulerHook'),
    sampler_seed=dict(type='DistSamplerSeedHook'),
    timer=dict(type='IterTimerHook'),
    visualization=dict(enable=False, type='PoseVisualizationHook'))
default_scope = 'mmpose'
env_cfg = dict(
    cudnn_benchmark=False,
    dist_cfg=dict(backend='nccl'),
    mp_cfg=dict(mp_start_method='fork', opencv_num_threads=0))
launcher = 'none'
load_from = '/kaggle/working/petlens-colab-100step/models/rtmpose-m_simcc-ap10k_pt-aic-coco_210e-256x256-7a041aa1_20230206.pth'
log_level = 'INFO'
log_processor = dict(
    by_epoch=False, num_digits=6, type='LogProcessor', window_size=50)
max_epochs = 210
model = dict(
    backbone=dict(
        _scope_='mmdet',
        act_cfg=dict(type='SiLU'),
        arch='P5',
        channel_attention=True,
        deepen_factor=0.67,
        expand_ratio=0.5,
        frozen_stages=4,
        init_cfg=None,
        norm_cfg=dict(type='SyncBN'),
        norm_eval=True,
        out_indices=(4, ),
        type='CSPNeXt',
        widen_factor=0.75),
    data_preprocessor=dict(
        bgr_to_rgb=True,
        mean=[
            123.675,
            116.28,
            103.53,
        ],
        std=[
            58.395,
            57.12,
            57.375,
        ],
        type='PoseDataPreprocessor'),
    head=dict(
        decoder=dict(
            input_size=(
                256,
                256,
            ),
            normalize=False,
            sigma=(
                5.66,
                5.66,
            ),
            simcc_split_ratio=2.0,
            type='SimCCLabel',
            use_dark=False),
        final_layer_kernel_size=7,
        gau_cfg=dict(
            act_fn='SiLU',
            drop_path=0.0,
            dropout_rate=0.0,
            expansion_factor=2,
            hidden_dims=256,
            pos_enc=False,
            s=128,
            use_rel_bias=False),
        in_channels=768,
        in_featuremap_size=(
            8,
            8,
        ),
        input_size=(
            256,
            256,
        ),
        loss=dict(
            beta=10.0,
            label_softmax=True,
            type='KLDiscretLoss',
            use_target_weight=True),
        out_channels=17,
        simcc_split_ratio=2.0,
        type='PreservedPawHead'),
    test_cfg=dict(flip_test=False),
    type='TopdownPoseEstimator')
optim_wrapper = dict(
    clip_grad=dict(max_norm=1.0, norm_type=2),
    optimizer=dict(lr=1e-05, type='AdamW', weight_decay=0.0),
    type='OptimWrapper')
param_scheduler = []
randomness = dict(deterministic=True, seed=20261104)
resume = False
stage2_num_epochs = 30
test_cfg = dict(type='TestLoop')
test_dataloader = dict(
    batch_size=4,
    dataset=dict(
        ann_file=
        'reports/rtmpose-paw-v2-experiment/temporal-diagnostic.coco.json',
        data_mode='topdown',
        data_prefix=dict(img='reports/paw-annotation-data-v1/'),
        data_root='',
        metainfo=dict(
            from_file=
            '/kaggle/working/petlens-env/lib/python3.10/site-packages/mmpose/.mim/configs/_base_/datasets/ap10k.py'
        ),
        pipeline=[
            dict(type='LoadImage'),
            dict(padding=1.25, type='GetBBoxCenterScale'),
            dict(input_size=(
                256,
                256,
            ), type='TopdownAffine'),
            dict(type='PackPoseInputs'),
        ],
        test_mode=True,
        type='AP10KDataset'),
    drop_last=False,
    num_workers=0,
    persistent_workers=False,
    sampler=dict(round_up=False, shuffle=False, type='DefaultSampler'))
test_evaluator = dict(
    ann_file='reports/rtmpose-paw-v2-experiment/temporal-diagnostic.coco.json',
    type='ReviewedPawMetric')
train_cfg = dict(max_iters=100, type='IterBasedTrainLoop', val_interval=100)
train_dataloader = dict(
    batch_size=4,
    dataset=dict(
        ann_file='reports/rtmpose-paw-v2-experiment/pilot-train.coco.json',
        data_mode='topdown',
        data_prefix=dict(img='reports/paw-annotation-data-v1/'),
        data_root='',
        metainfo=dict(
            from_file=
            '/kaggle/working/petlens-env/lib/python3.10/site-packages/mmpose/.mim/configs/_base_/datasets/ap10k.py'
        ),
        pipeline=[
            dict(type='LoadImage'),
            dict(padding=1.25, type='GetBBoxCenterScale'),
            dict(input_size=(
                256,
                256,
            ), type='TopdownAffine'),
            dict(
                encoder=dict(
                    input_size=(
                        256,
                        256,
                    ),
                    normalize=False,
                    sigma=(
                        5.66,
                        5.66,
                    ),
                    simcc_split_ratio=2.0,
                    type='SimCCLabel',
                    use_dark=False),
                type='GenerateTarget'),
            dict(type='PackPoseInputs'),
        ],
        type='AP10KDataset'),
    num_workers=0,
    persistent_workers=False,
    sampler=dict(shuffle=True, type='InfiniteSampler'))
train_pipeline = [
    dict(type='LoadImage'),
    dict(padding=1.25, type='GetBBoxCenterScale'),
    dict(input_size=(
        256,
        256,
    ), type='TopdownAffine'),
    dict(
        encoder=dict(
            input_size=(
                256,
                256,
            ),
            normalize=False,
            sigma=(
                5.66,
                5.66,
            ),
            simcc_split_ratio=2.0,
            type='SimCCLabel',
            use_dark=False),
        type='GenerateTarget'),
    dict(type='PackPoseInputs'),
]
train_pipeline_stage2 = [
    dict(backend_args=dict(backend='local'), type='LoadImage'),
    dict(type='GetBBoxCenterScale'),
    dict(direction='horizontal', type='RandomFlip'),
    dict(type='RandomHalfBody'),
    dict(
        rotate_factor=60,
        scale_factor=[
            0.75,
            1.25,
        ],
        shift_factor=0.0,
        type='RandomBBoxTransform'),
    dict(input_size=(
        256,
        256,
    ), type='TopdownAffine'),
    dict(type='mmdet.YOLOXHSVRandomAug'),
    dict(
        transforms=[
            dict(p=0.1, type='Blur'),
            dict(p=0.1, type='MedianBlur'),
            dict(
                max_height=0.4,
                max_holes=1,
                max_width=0.4,
                min_height=0.2,
                min_holes=1,
                min_width=0.2,
                p=0.5,
                type='CoarseDropout'),
        ],
        type='Albumentation'),
    dict(
        encoder=dict(
            input_size=(
                256,
                256,
            ),
            normalize=False,
            sigma=(
                5.66,
                5.66,
            ),
            simcc_split_ratio=2.0,
            type='SimCCLabel',
            use_dark=False),
        type='GenerateTarget'),
    dict(type='PackPoseInputs'),
]
val_cfg = dict(type='ValLoop')
val_dataloader = dict(
    batch_size=4,
    dataset=dict(
        ann_file=
        'reports/rtmpose-paw-v2-experiment/temporal-diagnostic.coco.json',
        data_mode='topdown',
        data_prefix=dict(img='reports/paw-annotation-data-v1/'),
        data_root='',
        metainfo=dict(
            from_file=
            '/kaggle/working/petlens-env/lib/python3.10/site-packages/mmpose/.mim/configs/_base_/datasets/ap10k.py'
        ),
        pipeline=[
            dict(type='LoadImage'),
            dict(padding=1.25, type='GetBBoxCenterScale'),
            dict(input_size=(
                256,
                256,
            ), type='TopdownAffine'),
            dict(type='PackPoseInputs'),
        ],
        test_mode=True,
        type='AP10KDataset'),
    drop_last=False,
    num_workers=0,
    persistent_workers=False,
    sampler=dict(round_up=False, shuffle=False, type='DefaultSampler'))
val_evaluator = dict(
    ann_file='reports/rtmpose-paw-v2-experiment/temporal-diagnostic.coco.json',
    type='ReviewedPawMetric')
val_pipeline = [
    dict(type='LoadImage'),
    dict(padding=1.25, type='GetBBoxCenterScale'),
    dict(input_size=(
        256,
        256,
    ), type='TopdownAffine'),
    dict(type='PackPoseInputs'),
]
vis_backends = [
    dict(type='LocalVisBackend'),
]
visualizer = dict(
    name='visualizer',
    type='PoseLocalVisualizer',
    vis_backends=[
        dict(type='LocalVisBackend'),
    ])
work_dir = 'outputs/rtmpose-paw-v2-pilot'
